// src/routes/chatRoutes.js
import express from 'express';
// Import necessary controllers

const router = express.Router();

// Define chat-related routes

export default router;