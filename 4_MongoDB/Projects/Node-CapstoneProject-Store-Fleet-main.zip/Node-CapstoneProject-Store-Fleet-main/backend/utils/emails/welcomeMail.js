// Import the necessary modules here

export const sendWelcomeEmail = async (user) => {
  // Write your code here
};
